Put your custom SFS part definition files in this folder.
