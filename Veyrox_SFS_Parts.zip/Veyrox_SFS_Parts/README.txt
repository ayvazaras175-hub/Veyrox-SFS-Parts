Veyrox's SFS Parts
Starter project for a Spaceflight Simulator 1.6 parts pack.

Folders:
- parts/: place part definition files here.
- textures/: place PNG textures here.

Note:
This is an empty starter structure, not yet an installable SFS mod.
The exact part-definition format and loading method must match the mod loader/API
you intend to use. Add those files before installing in the game.
