Put PNG textures for your custom parts in this folder.
